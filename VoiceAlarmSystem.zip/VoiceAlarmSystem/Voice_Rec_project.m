 close all;clear all; clc
 
%Recording parameters
pass1 = [1 2];  %Fpass=pass1;
pass2 = [3 4];

Fs = 44100;     % Sampling frequency
T = 3;          % Recording time
n = 1;          % Number of samples for each digit
Fc = 2000;      % Cutoff frequency to remove noise

%Training parameters
NumNeigh = 2;   %Number of neighbors for Knn model

%%%%%%%%%%%%%%%%%%%%%%%%%%%

prompt111 = "*******************************************************"...
    +newline+ "Hello! please select one of the following: "...
    +newline+ "   1.ARM "...
    +newline+ "   2.SETTINGS ";

prompt222 = "*******************************************************"...
    +newline+ "Device Armed! please select one of the following: "...
    +newline+ "   1.DISARM ";

prompt55 = "*******************************************************"...
    +newline+ "Please select one of the following: "...
    +newline+ "   1.Training Data Plot  "...
    +newline+ "   2.Voice Input Data Plot ";

prompt2 = "INCORRECT, try again";
prompt3 = "CORRECT, thank you!";

prompt4 = "please select on of the following: "...
    +newline+ "   1.passcode "...
    +newline+ "   2.voice ";

prompt5 ="Device ARMED";
prompt6="Device DISARMED";

prompt7="Welcome to Settings. please select one of the following: "...
    +newline+ "   1.change passcode "...
    +newline+ "   2.change voice "...
    +newline+ "   3.tune voice "...
    +newline+ "   4.engineering menu ";

prompt8="Please enter passcode:";
prompt9="Please speak now";

prompt10="Enter the desired user [1-5] " ;

prompt11="Enter the FIRST desired password [1 Digit only]";
prompt16="Enter the SECOND desired password [1 Digit only]";


prompt12 ="Your password has successfully stored";
prompt13 = "Enter the FIRST desired voice password [1 Digit only]";
prompt15 = "Enter the SECOND desired voice password [1 Digit only]";
prompt14 = "Your Voice password has successfully stored";

power =1; voicesetting=0; devicearmed=0;

while power == 1
    if(devicearmed==0)
        value1=input(prompt111); %arm  / settings
    elseif(devicearmed==1)
        value1=input(prompt222); % disarm
    end
    %--------------------------------------------------------
    if(value1==1 && devicearmed==0)%ARM
        
        value2=input(prompt4); %passcode / voice??
        if(value2==1) %passcode
            value3=input(prompt8); %passcode option
            value3_split=str2double(regexp(num2str(value3),'\d','match'));
            if(numel(value3_split)==2)
                if(value3_split(1)==pass1(1) && value3_split(2)==pass1(2))
                    disp(prompt3); %correct
                    disp(prompt5); %armed
                    devicearmed=1;
                elseif(value3_split(1) ~= pass1(1) || value3_split(2) ~= pass1(2))
                    pass_inc1=1;
                    while(pass_inc1==1)
                        disp(prompt2); %incorrect
                        incpass1=input(prompt8); %passcode option
                        incpass1_split=str2double(regexp(num2str(incpass1),'\d','match'));
                        if(incpass1_split==pass1)
                            disp(prompt3); %correct
                            disp(prompt5); %armed
                            pass_inc1=0;
                            devicearmed=1;
                        end
                    end
                end
            elseif(numel(value3_split)~=2)
                disp(prompt2); %incorrect
            end
        elseif(value2==2)%voice option
            if(voicesetting==0)
                disp('Please Set up Voice in Settings Menu!');
            elseif(voicesetting==1)
                [recObjVoice1]=inputVoice('User1Voice');
                [A,B,Output,D] = VerifyVoicePass(LFilt,K_model,'User1Voice.wav');
                if(Output(1)==pass2(1) && Output(2)==pass2(2))
                    disp(prompt3); %correct
                    disp(prompt5); %armed
                    pass_inc1=0;
                    devicearmed=1;
                elseif(Output(1)~=pass2(1) || Output(2)~=pass2(2))
                    inc_voice=1;
                    while(inc_voice==1)
                        disp(prompt2); %incorrect
                        [recObjVoice1]=inputVoice('User1Voice');
                        [A,B,Output2,D] = VerifyVoicePass(LFilt,K_model,'User1Voice.wav');
                        if(Output2==pass2)
                            disp(prompt3); %correct
                            disp(prompt5); %armed
                            devicearmed=1;
                            inc_voice=0;
                        end
                    end
                end
            end
        end
        %--------------------------------------------------------
    elseif(value1==1 && devicearmed==1) %DISARM
        value2=input(prompt4); %passcode / voice??
        if(value2==1) %passcode
            value3=input(prompt8); %passcode option
            value3_split=str2double(regexp(num2str(value3),'\d','match'));
            if(numel(value3_split)==2)
                if(value3_split(1)==pass1(1) && value3_split(2)==pass1(2))
                    disp(prompt3); %correct
                    disp(prompt6); %disarmed
                    devicearmed=0;
                elseif(value3_split(1) ~= pass1(1) || value3_split(2) ~= pass1(2))
                    pass_inc2=1;
                    while(pass_inc2==1)
                        disp(prompt2); %incorrect
                        incpass2=input(prompt8); %passcode option
                        incpass2_split=str2double(regexp(num2str(incpass2),'\d','match'));
                        if(incpass2_split==pass1)
                            disp(prompt3); %correct
                            disp(prompt6); %disarmed
                            pass_inc2=0;
                            devicearmed=0;
                            
                        end
                    end
                end
            end
            
        elseif(value2==2) %voice
            if(voicesetting==0)
                disp('Please Set up Voice in Settings Menu!');
            elseif(voicesetting==1)
                [recObjVoice2]=inputVoice('User1Voice');
                [A,B,Output,D] = VerifyVoicePass(LFilt,K_model,'User1Voice.wav');
                if(Output(1)==pass2(1) && Output(2)==pass2(2))
                    disp(prompt3); %correct
                    disp(prompt6); %disarmed
                    pass_inc1=0;
                    devicearmed=0;
                elseif(Output(1)~=pass2(1) || Output(2)~=pass2(2))
                    inc_voice=1;
                    while(inc_voice==1)
                        disp(prompt2); %incorrect
                        [recObjVoice2]=inputVoice('User1Voice');
                        [A,B,Output2,D] = VerifyVoicePass(LFilt,K_model,'User1Voice.wav');
                        if(Output(1)==pass2(1) && Output(2)==pass2(2))
                            disp(prompt3); %correct
                            disp(prompt6); %disarmed
                            devicearmed=0;
                            inc_voice=0;
                        end
                    end
                end
            end
        end
        %--------------------------------------------------------
    elseif(value1==2 && devicearmed==0) %Settings
        value2=input(prompt7);
        if(value2==1)%change password
            value4(1)=input(prompt11);
            
            if(max(ceil(log10(abs(value4(1)))),1)==1)
           
                Fpass2(1)=value4(1);
                value4(2)=input(prompt16);
                
                if(max(ceil(log10(abs(value4(2)))),1)==1)
                    Fpass2(2)=value4(2);
                    disp(prompt14);
                    disp(prompt12);
                    pass1=value4; %change pass1
                end
            elseif(max(ceil(log10(abs(value4(1)))),1)~= 1)
                disp("INCORRECT ATTEMPT! Aborted");
            end
            
        elseif(value2==2)%change voice
            voicesetting=1;
            value4(1)=input(prompt13);
            
            if(max(ceil(log10(abs(value4(1)))),1)==1)
                pass1=value4; %change pass1
                %Fpass2=pass1;
                Fpass(1)=value4(1);
                value4(2)=input(prompt15);
                
                if(max(ceil(log10(abs(value4(2)))),1)==1)
                    Fpass(2)=value4(2);
                    disp(prompt14);
                    disp(prompt12);
                    Fpass=pass2;
                    pass2=value4; %change pass1
                end
            elseif(max(ceil(log10(abs(value4(1)))),1)~= 1)
                disp("INCORRECT ATTEMPT! Aborted");
            end
        elseif(value2==3)%tune voice
            [recObj1]=training;
            [LFilt,K_model,bb,KK_result,KK_error]=tuning;
        elseif(value2==4)%engineering menu
            value11=input(prompt55);
            if(value11==1) %Training Plot 
                close all; 
                plot(bb,'b')
                hold on
                plot(KK_result,'*k')
                hold off
                legend('Training Data','Model Output')
                title(['Error = ' num2str(KK_error) '%']);
            elseif(value11==2) %Voice Inputs Data (1st Attempt)
                close all;
                load handel.mat;
                [yy, fs]=audioread('User1Voice.wav');
                N = length(yy);% % N is the number of samples
                y = yy + 0.002*randn(length(yy),1); 
                sound(y, fs);    % Playback of the sound data
                time=(1:length(yy))/fs;  % Time vector on x-axis
                recorder=getaudiodata(recObjVoice1);
                subplot(3,1,1);
                idx = find(recorder~=0, 1, 'first');
                xlim([idx 90000]);
                plot(time,y*1.2) ;
                xlabel('Time'); title('Audio Sample Before Filtering');
                subplot(3,1,2)
                plot(time,D)
                xlabel('Time');  title('Audio Sample After Filtering');
                subplot(3,1,3)
                plot(B)
                legend('First Digit','Second Digit)')
                xlabel('Time');  title('Audio Decomposition per Digit');
            end

        end
        
    end
end


function Voice_Rec(z)
Fs = 70000;
x=audioread(z);
voice=cov(x);
%
y0=audioread('RecordedSound.wav'); 	%'denied.wav' was used here as reference
y1=audioread('hello.wav');


h=audioread('allow.wav');


ref=cov(y0);
delta0 = abs(ref - voice);
sel = ref;
dif = abs(delta0);
upR = dif*1.2;
ddR=dif*0.8;

% all allowed wave files must be loaded and compared
% to the input, one at a time

one=cov(y1);
delta1 = abs(one - voice);
if (delta1 <= ddR && delta1 >=upR)
    sel = one;
    dif = abs(delta1);
    
end

if sel == one
    soundsc(y1,Fs)
    soundsc(h,Fs)
    play=1;
else soundsc(audioread('denied.wav'),Fs)
    play=0;
    
end
end

function [recObj]=training()
Fs = 44100;     % Sampling frequency
T = 3;         % Recording time
n = 1;            % Number of samples for each digit
Fc = 2000;      % Cutoff frequency to remove noise

%Training parameters
NumNeigh = 2;   %Number of neighbors for Knn model
mkdir('Train'); %Make folder called Train to save wav files
% Record your voice
recObj1 = audiorecorder(Fs,8,1);
for i=0:5
    disp(['Get ready ... to say the digit ' num2str(i)])
    pause(2)
    disp('Start speaking.')
    recordblocking(recObj1, T);
    % Store data in double-precision array.
    myRecording = getaudiodata(recObj1);
    FileName = ['Train\' num2str(i) '_1'];
    audiowrite([FileName '.wav'],myRecording,Fs);
    for j=2:n
        disp('again')
        recordblocking(recObj1, 3);
        % Store data in double-precision array.
        myRecording = getaudiodata(recObj1);
        FileName = ['Train\' num2str(i) '_' num2str(j)];
        audiowrite([FileName '.wav'],myRecording,Fs);
    end
end
recObj=myRecording; 
disp('End of Recording.');
disp('VOICE SUCCESSFULLY TUNED');
end

function [recObjVoice]=inputVoice(Name)
Fs = 44100;     % Sampling frequency
T = 3;           % Recording time
n = 1;          % Number of samples for each digit
Fc = 2000;      % Cutoff frequency to remove noise

%Training parameters
NumNeigh = 2;   %Number of neighbors for Knn model
m = 2;
voice = zeros(T*Fs,m); %Preallocation for recordings
recObj = audiorecorder(Fs,8,1);
disp('Get ready ... to say TWO digits (ONE AT A TIME) ')
for i=1:m
    pause(2)
    disp(['Say digit number ' num2str(i)])
    recordblocking(recObj, T);
    % Store data in double-precision array.
    voice(:,i) = getaudiodata(recObj);
end
disp('End of Recording.');
voice = reshape(voice,numel(voice),[]);

audiowrite([Name '.wav'],voice,Fs);
%audiowrite([RawName '.wav'],voice,Fs); 
recObjVoice =recObj; 
end

function [x,y,bb,KK_result,KK_error] = tuning()
Fs = 44100;     % Sampling frequency
T = 3;           % Recording time
n = 1;            % Number of samples for each digit
Fc = 2000;      % Cutoff frequency to remove noise

%Training parameters
NumNeigh = 2;   %Number of neighbors for Knn model
%Low pass filter to remove noise
d=fdesign.lowpass('Fp,Fst,Ap,Ast',2/Fs*0.95*Fc,2/Fs*Fc,1,60);
LFilt = design(d,'equiripple');
x=LFilt;
%loading voice
USER = zeros(6*n,T*Fs); % Preallocation for recordings
for i=0:5
    for j=1:n
        [tmp,~] = audioread(['Train\' num2str(i) '_' num2str(j) '.wav']);
        USER(i*n+j,:) = filter(LFilt,tmp);
    end
end
%Feature extractions (pitch)
df = Fs/size(USER,2); ff = (-Fs/2:df:Fs/2-df)';
ff(1:fix(length(ff)/2)) = [];
idx = find(ff>Fc); ff(idx)=[];
[ff,ia,~] = unique(roundn(ff,2));
Features = zeros(6*n,length(ff)); %Preallocation for features
for i=1:6*n
    Y = abs(fftshift(fft(USER(i,:))));
    Y(1:fix(length(Y)/2)) = [];
    Y(idx)=[];
    Y = Y/max(Y);
    Features(i,:) = Y(ia);
end
%Exact output
out = [0*ones(n,1); 1*ones(n,1); 2*ones(n,1)
    3*ones(n,1); 4*ones(n,1); 5*ones(n,1)];
%Training Fuzzy logic model
K_model = fitcknn(Features,out,'NumNeighbors',NumNeigh);
K_result = predict(K_model,Features); % testing the model
K_error = ~(out==K_result); %Comparing result to exact result
K_error = sum(K_error); %Counting numbers of mistakes
K_error = 100*K_error/length(out); %Represent error as percent
bb=out;
KK_result=K_result;
KK_error=K_error; 
y=K_model;

end

function [A,B,C,D] = VerifyVoicePass(x,y,Name)
Fs = 44100;     % Sampling frequency
T = 3;          % Recording time
n = 1;            % Number of samples  for each digit
Fc = 2000;      % Cutoff frequency to remove noise
LFilt=x;
K_model=y;
%Training parameters
NumNeigh = 2;   %Number of neighbors for Knn model
%Input your voice file

[voice,~] = audioread(Name);
voicefilter=voice; 
voice = filter(LFilt,voice);
voiceAfilter=voice; 
tmp = (Fs*T*fix(length(voice)/(T*Fs)));
voice = voice(1:tmp);
voice = reshape(voice,T*Fs,[]);
voiceAAfilter=voice; 
%Extract voice features
df = Fs/size(voice,1); ff = (-Fs/2:df:Fs/2-df)';
ff(1:fix(length(ff)/2)) = [];
idx = find(ff>Fc); ff(idx)=[];
[ff,ia,~] = unique(roundn(ff,2)); m = size(voice,2);
Features = zeros(m,length(ff)); %Preallocation for features
for i=1:m
    Y = abs(fftshift(fft(voice(:,i))));
    Y(1:fix(length(Y)/2)) = [];
    Y(idx)=[];
    Y = Y/max(Y);
    
    Features(i,:) = Y(ia);
end
%Results
output = predict(K_model,Features);
warning('on')

A=voiceAfilter;
B=voiceAAfilter;
C=output;
D=voicefilter;

end

